package com.company;

import javax.swing.plaf.basic.BasicButtonUI;
import javax.tools.JavaFileManager;
import java.io.*;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FileUtils {
    private static int noteNumber = 1 ;

    private static final String NOTES_PATH = "./notes/";

    //It's a static initializer. It's executed when the class is loaded.
    //It's similar to constructor
    static {
        boolean isSuccessful = new File(NOTES_PATH).mkdirs();
        System.out.println("Creating " + NOTES_PATH + " directory is successful: " + isSuccessful);
    }

    public static File[] getFilesInDirectory() {
        return new File(NOTES_PATH).listFiles();
    }


    public static String fileReader(File file) {
        FileReader fr ;
        String r = "" ;
        try {
            fr = new FileReader(file) ;
            BufferedReader br  = new BufferedReader(fr) ;
            while (br.ready()){
                r += br.readLine() + "\n" ;
            }
            br.close() ;
            fr.close() ;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }
        return r ;
    }

    public static void fileWriter(String content) {
        String fileName = getProperFileName(content);
        FileWriter f ;
        try {
            f = new FileWriter("./notes/" + fileName) ;
            BufferedWriter bw = new BufferedWriter(f) ;
            bw.write(content) ;
            bw.close() ;
            f.close() ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }
    }

    public static String fileInputStreamReader (File file) {
        String r = "" ;
        try {
            FileInputStream fis = new FileInputStream(file) ;
            while (fis.available() > 0){
                r += (char) fis.read() ;
            }
            fis.close() ;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }
        return r ;
    }

    public static void fileOutputStreamWriter (String content){
        String fileName = getProperFileName(content);
        File file = new File("./notes/" + fileName) ;
        try {
            FileOutputStream fos = new FileOutputStream(file) ;
            char[] c = content.toCharArray() ;
            byte[] temp = new byte[c.length] ;
            for (int i = 0; i < temp.length; i++){
                temp[i] = (byte) c[i] ;
            }
            fos.write(temp) ;
            fos.close() ;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }

    }

    public static void objectFileWriter (Note note){
        File file = new File("./notes/" + getProperFileName(note.getContent())) ;
        try (FileOutputStream os = new FileOutputStream(file)) {
            ObjectOutputStream oos = new ObjectOutputStream(os) ;
            oos.writeObject(note) ;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }
    }

    public static Note objectFileReader (File file){
        Note note = null ;
        try (FileInputStream is = new FileInputStream(file)){
            BufferedInputStream bis = new BufferedInputStream(is);
            ObjectInputStream ois = new ObjectInputStream(bis) ;
            note = (Note) ois.readObject() ;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (IOException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(JavaFileManager.class.getName()).log(Level.SEVERE, null, ex) ;
        }
        return note ;
    }

    private static String getProperFileName(String content) {
        int loc = content.indexOf("\n");
        if (loc != -1) {
            return content.substring(0, loc);
        }
        if (!content.isEmpty()) {
            return content;
        }
        return System.currentTimeMillis() + "_new file.txt";
    }
}
