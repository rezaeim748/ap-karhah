package com.company;

import javax.swing.*;
import java.awt.*;

/**
 * Make two kinds of calculator
 */
public class TabbedPaneExample {
        JFrame calcFrame;
        TabbedPaneExample(){
            calcFrame=new JFrame();
            calcFrame.setTitle("AUT Calculator");
            calcFrame.setSize(400,400);
            calcFrame.setLocation(50, 100);
            calcFrame.setLayout(null);
            calcFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


            JTabbedPane tp=new JTabbedPane();
            tp.setBounds(10,10,300,300);

            JPanel pb1 = new JPanel() ;
            pb1.setLayout(new BorderLayout());
            JTextField tf1 = new JTextField();
            JButton btn = new JButton() ;
            btn.setText("AC");
            pb1.add(tf1, BorderLayout.CENTER) ;
            pb1.add(btn, BorderLayout.EAST) ;

            JPanel pb2 = new JPanel() ;
            pb2.setLayout(new BorderLayout());
            JTextField tf2 = new JTextField();
            pb2.add(tf2, BorderLayout.CENTER) ;

            JPanel pg1=new JPanel();
            pg1.setLayout(new GridLayout(4, 4));
            addButtonsToRegular(pg1);
            pb1.add(pg1, BorderLayout.SOUTH) ;

            JPanel pg2 = new JPanel() ;
            pg2.setLayout(new GridLayout(7, 4));
            addButtonsToAdvanced(pg2);
            pb2.add(pg2, BorderLayout.SOUTH) ;


            tp.add("regular",pb1);
            tp.add("advanced",pb2);

            calcFrame.add(tp);

            calcFrame.setVisible(true);
        }


    /**
     * Add buttons to regular calculator
     * @param p The JPanel which contains calculator buttons
     */
    public void addButtonsToRegular (JPanel p){
            JButton btn = new JButton();
            btn.setText("1");
            p.add(btn);

            btn = new JButton();
            btn.setText("2");
            p.add(btn);

            btn = new JButton();
            btn.setText("3");
            p.add(btn);

            btn = new JButton();
            btn.setText("*");
            p.add(btn);

            btn = new JButton();
            btn.setText("4");
            p.add(btn);

            btn = new JButton();
            btn.setText("5");
            p.add(btn);

            btn = new JButton();
            btn.setText("6");
            p.add(btn);

            btn = new JButton();
            btn.setText("/");
            p.add(btn);

            btn = new JButton();
            btn.setText("7");
            p.add(btn);

            btn = new JButton();
            btn.setText("8");
            p.add(btn);

            btn = new JButton();
            btn.setText("9");
            p.add(btn);

            btn = new JButton();
            btn.setText("%");
            p.add(btn);

            btn = new JButton();
            btn.setText("+");
            p.add(btn);

            btn = new JButton();
            btn.setText("0");
            p.add(btn);

            btn = new JButton();
            btn.setText("-");
            p.add(btn);

            btn = new JButton();
            btn.setText("=");
            p.add(btn);
        }

    /**
     * Add buttons to advanced calculator
     * @param p The JPanel which contains calculator buttons
     */
    public void addButtonsToAdvanced (JPanel p){
            JButton btn = new JButton();
            btn.setText("log");
            p.add(btn);

            btn = new JButton();
            btn.setText("ln");
            p.add(btn);

            btn = new JButton();
            btn.setText("exp");
            p.add(btn);

            btn = new JButton();
            btn.setText("pow");
            p.add(btn);

            btn = new JButton();
            btn.setText("pi");
            p.add(btn);

            btn = new JButton();
            btn.setText("nrp");
            p.add(btn);

            btn = new JButton();
            btn.setText("sin");
            p.add(btn);

            btn = new JButton();
            btn.setText("tan");
            p.add(btn);

            btn = new JButton();
            btn.setText("shift");
            p.add(btn);

            btn = new JButton();
            btn.setText("");
            p.add(btn);

            btn = new JButton();
            btn.setText("DEL");
            p.add(btn);

            btn = new JButton();
            btn.setText("AC");
            p.add(btn);

            btn = new JButton();
            btn.setText("1");
            p.add(btn);

            btn = new JButton();
            btn.setText("2");
            p.add(btn);

            btn = new JButton();
            btn.setText("3");
            p.add(btn);

            btn = new JButton();
            btn.setText("*");
            p.add(btn);

            btn = new JButton();
            btn.setText("4");
            p.add(btn);

            btn = new JButton();
            btn.setText("5");
            p.add(btn);

            btn = new JButton();
            btn.setText("6");
            p.add(btn);

            btn = new JButton();
            btn.setText("/");
            p.add(btn);

            btn = new JButton();
            btn.setText("7");
            p.add(btn);

            btn = new JButton();
            btn.setText("8");
            p.add(btn);

            btn = new JButton();
            btn.setText("9");
            p.add(btn);

            btn = new JButton();
            btn.setText("%");
            p.add(btn);

            btn = new JButton();
            btn.setText("+");
            p.add(btn);

            btn = new JButton();
            btn.setText("0");
            p.add(btn);

            btn = new JButton();
            btn.setText("-");
            p.add(btn);

            btn = new JButton();
            btn.setText("=");
            p.add(btn);

        }
}
