package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {




    /**
     * Convert the given string to integer
     * @param string The string to be converted
     * @return An Integer which stores the integer part of the given string
     */
    public static int myParseInt (String string){
        try{
            return Integer.parseInt(string) ;
        }
        catch (Exception e){
            return -1 ;
        }

    }

    /**
     * Check if the given number is positive or not
     * @param number The number to be checked
     * @return An Integer which stores the given number if its positive
     */
    public static int isPositive (int number){
        if (number < 0){
            return -1 ;
        }
        else {
            return number ;
        }
    }









    public static void main(String[] args) {

        Scanner reader = new Scanner(System.in) ;

        VotingSystem votingSystem = new VotingSystem() ;


        String temp ;
        String[] tempArr ;
        int size ;
        int counter ;
        int onVotingNumber = 0 ;

        while (true){

            temp = reader.nextLine() ;
            tempArr = temp.split(" ") ;
            size = tempArr.length ;



            if (size == 1){
                if (tempArr[0].equals("exit")) {
                    break ;
                }



                else if (tempArr[0].equals("vote")){
                    if (onVotingNumber == 0){
                        System.out.println("please specify the voting you want to participate in") ;
                    }
                    else {
                        System.out.print("voter full name: ") ;
                        String voterName = reader.nextLine() ;
                        if (!(votingSystem.votingList.get(onVotingNumber - 1).hasVote(voterName))){
                            Person voter = new Person(voterName) ;
                            votingSystem.votingList.get(onVotingNumber - 1).setVoter(voter) ;
                            counter = 1 ;
                            while (counter <= votingSystem.votingList.get(onVotingNumber - 1).getType()){

                                System.out.print("candidate number " + counter + " name: ") ;
                                String candidateName = reader.nextLine() ;
                                if (candidateName.isEmpty()){
                                    if (counter == 1){
                                        System.out.println("you should choose at least one candidate") ;
                                    }
                                    else {
                                        break ;
                                    }
                                }
                                else if (!(votingSystem.votingList.get(onVotingNumber - 1).isCandidate(candidateName))){
                                    System.out.println("there is no candidate such as " + candidateName) ;
                                }
                                else {
                                    System.out.print("please enter the year: ") ;
                                    int dateYear = reader.nextInt() ;
                                    System.out.print("please enter the month: ") ;
                                    int dateMonth = reader.nextInt() ;
                                    System.out.print("please enter the day: ") ;
                                    int dateDay = reader.nextInt() ;
                                    Vote vote = new Vote(voter, dateDay, dateMonth, dateYear) ;
                                    votingSystem.votingList.get(onVotingNumber - 1).setVote(candidateName, vote) ;
                                    counter++ ;
                                    System.out.println("your vote has been stored") ;
                                }


                            }

                        }

                        else {
                            System.out.println(voterName + " has already voted") ;
                        }


                    }
                }

                else {
                    System.out.println("the way that you typed is incorrect") ;
                }

            }


            else if (size == 2){

                if (tempArr[0].equals("show")){
                    int votingNumber = Integer.parseInt(tempArr[1]) ;
                    if ((votingNumber <= 0) || (votingNumber > votingSystem.votingList.size())) {
                        System.out.println("there is no voting with number " + votingNumber) ;
                    }
                    else {
                        votingSystem.getResult(votingNumber) ;
                    }
                }



                else if ((tempArr[0].equals("voting")) && (tempArr[1].equals("-c"))){
                    System.out.print("question: ") ;
                    String question = reader.nextLine() ;
                    System.out.print("number of choices each person has: ") ;
                    int type = 0 ;
                    while (true) {
                        String typeString = reader.nextLine();
                        type = isPositive(myParseInt(typeString));
                        if (type == -1) {
                            System.out.println("Choose the number of choices correctly");
                            System.out.print("number of choices each person has: ") ;
                        }
                        else {
                            break ;
                        }
                    }

                    System.out.println("candidates: ") ;
                    ArrayList<String> candidates = new ArrayList<>() ;
                    counter = 1 ;
                    while (true){
                        System.out.print("candidate number " + counter + " : ") ;
                        String candidateName = reader.nextLine() ;
                        if ((candidateName.isEmpty()) && (counter > 2)){
                            break ;
                        }
                        else if ((candidateName.isEmpty()) && (counter <= 2)){
                            System.out.println("a voting must have at least two candidates") ;
                        }
                        else {
                            candidates.add(candidateName);
                            counter++ ;
                        }
                    }

                    votingSystem.creatVoting(question, type, candidates) ;
                    System.out.println("you have created a voting successfully") ;

                }

                else if ((tempArr[0].equals("voting")) && (tempArr[1].equals("-o"))){
                    onVotingNumber = 0 ;
                    System.out.println("you aren't in any voting") ;
                }

                else {
                    System.out.println("the way that you typed is incorrect") ;
                }
            }


            else if (size == 3){

                if ((tempArr[0].equals("voting")) && (tempArr[1].equals("-i"))) {
                    int votingNumber = Integer.parseInt(tempArr[2]);
                    if ((votingNumber <= 0) || (votingNumber > votingSystem.votingList.size())) {
                        System.out.println("there is no voting with number " + votingNumber);
                    } else {
                        onVotingNumber = votingNumber;
                        System.out.println("you have entered in voting number " + onVotingNumber) ;
                    }
                }
                else {
                    System.out.println("The way that you typed is incorrect") ;
                }
            }

            else {
                System.out.println("the way that you typed is incorrect") ;
            }












        }



























    }
}
