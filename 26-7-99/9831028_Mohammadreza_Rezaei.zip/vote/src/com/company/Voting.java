package com.company;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Voting {

    private int type ;
    private String question ;
    private ArrayList<Person> voters ;
    private ArrayList<String> candidates ;
    private HashMap<String, HashSet<Vote>> polls ;


    /**
     * Perform any initialization that is required
     * @param question The question of the voting
     * @param type The number of choices each person has
     * @param candidates The candidates of the voting
     */
    public Voting (String question, int type, ArrayList<String> candidates){

        this.question = question ;
        this.type = type ;
        this.candidates = new ArrayList<>() ;
        this.candidates = candidates ;
        voters = new ArrayList<>() ;
        polls = new HashMap<>() ;
        creatPolls() ;
    }





    /**
     * Check if a person has voted or not
     * @param fullName The name of the person
     * @return A boolean which shows the person has voted or not
     */
    public boolean hasVote (String fullName){

        for (Person person : voters){
            if (person.toString().equals(fullName)){
                return true ;
            }
        }
        return false ;
    }


    /**
     * Check a person is candidate or not
     * @param candidateName The person to be checked
     * @return A boolean which shows the person is candidate or not
     */
    public boolean isCandidate (String candidateName){

        for (String name : candidates){
            if (name.equals(candidateName)){
                return true ;
            }
        }
        return false ;
    }


    /**
     * Add a voter
     * @param voter The voter to be added
     */
    public void setVoter (Person voter){ voters.add(voter) ;}


    /**
     * Get the type of the voting
     * @return An Integer which shows the type of the voting
     */
    public int getType (){ return type ;}


    /**
     * Create polls
     */
    public void creatPolls (){
        for (String candidate : candidates){
            creatPoll(candidate) ;
        }
    }


    /**
     * Create a poll for a candidate
     * @param candidateName The candidate whose poll is created
     */
    public void creatPoll (String candidateName){ polls.put(candidateName, new HashSet<>()) ;}


    /**
     * Set a vote for a candidate
     * @param candidateName The name of the candidate
     * @param vote The vote to be set
     */
    public void setVote (String candidateName, Vote vote){ polls.get(candidateName).add(vote) ;}


    /**
     * Get polls
     * @return A HashMap which contains candidates name an votes
     */
    public HashMap<String, HashSet<Vote>> getPolls (){ return polls ;}


    /**
     * Get result
     */
    public void getResult (){

        for (Map.Entry<String, HashSet<Vote>> entry : polls.entrySet()){

            String candidateName = entry.getKey() ;
            System.out.println(candidateName + " votes number: " + entry.getValue().size()) ;
        }
    }









}
