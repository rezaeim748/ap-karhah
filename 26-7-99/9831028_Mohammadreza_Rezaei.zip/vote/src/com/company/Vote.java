package com.company;

import ir.huri.jcal.JalaliCalendar;

public class Vote {

    private Person person ;
    private JalaliCalendar jalaliCalendar ;


    /**
     * Perform any initialization that is required
     * @param person The voter
     * @param dateDay The day of the vote
     * @param dateMonth The month of the vote
     * @param dateYear The year of the vote
     */
    public Vote (Person person, int dateDay, int dateMonth, int dateYear){

        this.person = person ;
        jalaliCalendar = new JalaliCalendar(dateYear, dateMonth, dateDay) ;
    }




    public Person getPerson (){return person ;}


    public JalaliCalendar getDate (){ return jalaliCalendar ;}












}
