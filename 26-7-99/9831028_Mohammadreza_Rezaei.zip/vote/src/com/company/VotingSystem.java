package com.company;

import java.util.ArrayList;

public class VotingSystem {

    ArrayList<Voting> votingList ;


    /**
     * Perform any initialization that is required
     */
    public VotingSystem (){
        votingList = new ArrayList<>() ;
    }




    /** Create a voting
     * @param question The question of the voting
     * @param type The type of the voting
     * @param candidates The candidates of the voting
     */
    public void creatVoting (String question, int type, ArrayList<String> candidates){

        votingList.add(new Voting(question, type, candidates)) ;
    }


    /**
     * Get the voting list
     */
    public void getVotingList (){}


    /**
     * Get a voting
     * @param votingNumber The number of the voting to be gotten
     * @return A Voting which we want to get
     */
    public Voting getVoting (int votingNumber){ return votingList.get(votingNumber - 1) ;}


    /**
     * Vote for a candidate
     * @param votingNumber The number of the voting
     * @param candidateName The name of the candidate
     * @param vote The vote
     */
    public void vote (int votingNumber, String candidateName, Vote vote){

        votingList.get(votingNumber - 1).setVote(candidateName, vote) ;
    }


    /**
     * Get result of a voting
     * @param votingNumber The number of the voting
     */
    public void getResult (int votingNumber){

        votingList.get(votingNumber - 1).getResult() ;
    }


}
