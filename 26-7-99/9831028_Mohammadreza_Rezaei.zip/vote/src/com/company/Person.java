package com.company;


import java.util.ArrayList;

public class Person {

    private String firstName ;
    private String lastName ;
    private ArrayList<Vote> votes ;


    /**
     * Perform any initialization that is required
     * @param fullName The name of the person
     */
    public Person (String fullName){

        String[] fullNameParts = fullName.split(" ") ;
        this.firstName = fullNameParts[0] ;
        this.lastName = fullNameParts[1] ;
        votes = new ArrayList<>() ;
    }





    public String getFirstName (){ return firstName ;}


    public String getLastName (){ return lastName ;}


    /**
     * Get the string which represents the person
     * @return The String which represents the person
     */
    public String toString(){ return (firstName + " " + lastName) ;}
}
